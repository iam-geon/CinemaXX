// Example separated JS

function showPage(page){
    console.log("Navigasi ke halaman:", page);
}

function togglePassword(){
    console.log("Toggle password");
}
